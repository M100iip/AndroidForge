package ir.sedayemardom.karaj

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

data class Issue(
    val id: String,
    val title: String,
    val category: String,
    val location: String,
    val description: String,
    var status: String = "ثبت‌شده در دستگاه"
)

class MainActivity : Activity() {
    private val green = Color.rgb(21, 92, 77)
    private val teal = Color.rgb(20, 119, 101)
    private val pale = Color.rgb(239, 246, 243)
    private val ink = Color.rgb(25, 58, 50)
    private val muted = Color.rgb(100, 122, 114)
    private val issues = mutableListOf<Issue>()
    private var page = "home"
    private var role = "شهروند"
    private var selectedCategory = "معابر و آسفالت"
    private var selectedIssue = 0
    private val categories = listOf("معابر و آسفالت", "آب و فاضلاب", "برق و روشنایی", "جمع‌آوری زباله", "فضای سبز", "ساختمان و سازه", "سایر موارد")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = green
        showPage()
    }

    private fun bg(color: Int, radius: Float = 20f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float = 16f, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_RTL
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit, primary: Boolean = true): TextView =
        text(label, 15f, if (primary) Color.WHITE else green, true).apply {
            gravity = Gravity.CENTER
            background = bg(if (primary) teal else Color.WHITE, 18f)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            isClickable = true
            setOnClickListener { onClick() }
            if (!primary) {
                val gd = background as GradientDrawable
                gd.setStroke(dp(1), teal)
            }
        }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(14), dp(16), dp(12))
    }

    private fun addGap(parent: LinearLayout, height: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addCard(parent: LinearLayout, child: View, padding: Int = 10) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bg(Color.WHITE, 22f)
            setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            addView(child)
        }
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
    }

    private fun showPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(pale)
        }
        val scroll = ScrollView(this)
        val content = column()
        content.addView(text("صدای مردم  •  کرج", 21f, green, true))
        content.addView(text("سامانهٔ مستقل ثبت و پیگیری مشکلات شهری", 12f, muted))
        addGap(content, 12)

        when (page) {
            "home" -> {
                addCard(content, column().apply {
                    setBackgroundColor(Color.TRANSPARENT)
                    addView(text("سلام، شهروند عزیز", 14f, muted))
                    addGap(this, 4)
                    addView(text("مشکلی در شهر دارید؟", 23f, green, true))
                    addView(text("مشکل را ثبت کنید و کد پیگیری خود را نگه دارید.", 14f, muted))
                    addGap(this, 8)
                    addView(button("＋  ثبت مشکل جدید", { page = "new"; showPage() }))
                })
                addCard(content, column().apply {
                    setBackgroundColor(Color.TRANSPARENT)
                    addView(text("خدمات", 18f, green, true))
                    addView(button("درخواست‌های من (${issues.size})", { page = "requests"; showPage() }, false))
                    addGap(this)
                    addView(button("پیگیری وضعیت", { page = "track"; showPage() }, false))
                    addGap(this)
                    addView(button("دسته‌بندی مشکلات", { page = "categories"; showPage() }, false))
                    addGap(this)
                    addView(button("پروفایل و پنل مسئولان", { page = "profile"; showPage() }, false))
                })
                addCard(content, text("دسته‌های رایج", 17f, green, true))
                categories.take(6).forEach { cat ->
                    addCard(content, button(cat, { selectedCategory = cat; page = "new"; showPage() }, false))
                }
            }
            "new" -> {
                content.addView(button("← بازگشت", { page = "home"; showPage() }, false))
                addGap(content)
                content.addView(text("ثبت مشکل جدید", 22f, green, true))
                content.addView(text("نوع مشکل را انتخاب کنید", 14f, muted))
                categories.forEach { cat ->
                    content.addView(button((if (cat == selectedCategory) "✓  " else "") + cat, {
                        selectedCategory = cat; showPage()
                    }, cat == selectedCategory))
                    addGap(content, 5)
                }
                val titleInput = EditText(this).apply {
                    hint = "عنوان کوتاه مشکل"
                    textDirection = View.TEXT_DIRECTION_RTL
                    gravity = Gravity.RIGHT
                    setSingleLine(true)
                    background = bg(Color.WHITE, 14f)
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                }
                val descInput = EditText(this).apply {
                    hint = "شرح دقیق مشکل"
                    textDirection = View.TEXT_DIRECTION_RTL
                    gravity = Gravity.RIGHT or Gravity.TOP
                    minLines = 3
                    background = bg(Color.WHITE, 14f)
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                }
                val locationInput = EditText(this).apply {
                    hint = "محله و نشانی تقریبی در کرج"
                    textDirection = View.TEXT_DIRECTION_RTL
                    gravity = Gravity.RIGHT
                    setSingleLine(true)
                    background = bg(Color.WHITE, 14f)
                    setPadding(dp(12), dp(12), dp(12), dp(12))
                }
                addGap(content)
                content.addView(titleInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                content.addView(descInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                content.addView(locationInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
                content.addView(button("ثبت در این دستگاه", {
                    val t = titleInput.text.toString().trim()
                    val d = descInput.text.toString().trim()
                    val l = locationInput.text.toString().trim()
                    if (t.isBlank() || d.isBlank() || l.isBlank()) {
                        Toast.makeText(this, "عنوان، شرح و محل مشکل را وارد کنید.", Toast.LENGTH_LONG).show()
                    } else {
                        val id = "KJ-" + (issues.size + 1).toString().padStart(4, '0')
                        issues.add(0, Issue(id, t, selectedCategory, l, d))
                        selectedIssue = 0
                        page = "requests"
                        Toast.makeText(this, "درخواست محلی با کد $id ثبت شد.", Toast.LENGTH_LONG).show()
                        showPage()
                    }
                }))
                addGap(content)
                content.addView(text("توجه: این نسخه فقط اطلاعات را روی فهرست موقت داخل برنامه نگه می‌دارد؛ چیزی به شهرداری ارسال نمی‌شود.", 12f, muted))
            }
            "categories" -> {
                content.addView(button("← بازگشت", { page = "home"; showPage() }, false))
                addGap(content)
                content.addView(text("دسته‌بندی مشکلات", 22f, green, true))
                categories.forEach { cat ->
                    addCard(content, button(cat, { selectedCategory = cat; page = "new"; showPage() }, false))
                }
            }
            "requests" -> {
                content.addView(button("← بازگشت", { page = "home"; showPage() }, false))
                addGap(content)
                content.addView(text("درخواست‌های من", 22f, green, true))
                if (issues.isEmpty()) {
                    addCard(content, text("هنوز درخواستی ثبت نشده است.", 15f, muted))
                    content.addView(button("ثبت مشکل جدید", { page = "new"; showPage() }))
                } else issues.forEachIndexed { index, issue ->
                    addCard(content, column().apply {
                        setBackgroundColor(Color.TRANSPARENT)
                        addView(text(issue.title, 16f, green, true))
                        addView(text("${issue.id}  •  ${issue.category}", 12f, muted))
                        addView(text(issue.location, 13f, muted))
                        addView(text(issue.status, 13f, teal, true))
                        addGap(this, 5)
                        addView(button("مشاهدهٔ جزئیات", { selectedIssue = index; page = "track"; showPage() }, false))
                    })
                }
            }
            "track" -> {
                content.addView(button("← بازگشت", { page = "home"; showPage() }, false))
                addGap(content)
                content.addView(text("پیگیری وضعیت", 22f, green, true))
                if (issues.isEmpty()) {
                    addCard(content, text("درخواستی برای پیگیری وجود ندارد. می‌توانید یک درخواست آزمایشی ثبت کنید.", 15f, muted))
                    content.addView(button("ثبت مشکل", { page = "new"; showPage() }))
                } else {
                    val issue = issues.getOrElse(selectedIssue) { issues.first() }
                    addCard(content, column().apply {
                        setBackgroundColor(Color.TRANSPARENT)
                        addView(text(issue.title, 19f, green, true))
                        addView(text("کد پیگیری: ${issue.id}", 14f, muted))
                        addView(text("دسته: ${issue.category}", 14f))
                        addView(text("محل: ${issue.location}", 14f))
                        addView(text(issue.description, 14f, muted))
                        addGap(this, 12)
                        addView(text("مراحل رسیدگی", 18f, green, true))
                        addView(text("●  ثبت درخواست در این دستگاه", 14f, teal, true))
                        addView(text("○  بررسی توسط واحد مربوطه — در نسخهٔ واقعی", 13f, muted))
                        addView(text("○  اعلام نتیجه — هنوز پاسخی ثبت نشده", 13f, muted))
                    })
                }
            }
            "profile" -> {
                content.addView(button("← بازگشت", { page = "home"; showPage() }, false))
                addGap(content)
                content.addView(text("پروفایل و نقش کاربری", 22f, green, true))
                addCard(content, column().apply {
                    setBackgroundColor(Color.TRANSPARENT)
                    addView(text("انتخاب نقش نمایشی", 16f, green, true))
                    addView(button(if (role == "شهروند") "✓ شهروند" else "شهروند", { role = "شهروند"; showPage() }, role == "شهروند"))
                    addGap(this)
                    addView(button(if (role == "مسئول") "✓ مسئول رسیدگی" else "مسئول رسیدگی", { role = "مسئول"; showPage() }, role == "مسئول"))
                    addGap(this)
                    addView(text(if (role == "مسئول") "پنل نمایشی مسئولان: مشاهدهٔ درخواست‌ها و بررسی نمونه‌ای. احراز هویت و دسترسی واقعی وجود ندارد." else "پنل شهروند: ثبت و مشاهدهٔ درخواست‌های ذخیره‌شده در این دستگاه.", 13f, muted))
                    addGap(this)
                    addView(button("مشاهدهٔ درخواست‌ها", { page = "requests"; showPage() }, false))
                })
                addCard(content, text("نسخهٔ مستقل آزمایشی ۰٫۱ — بدون اتصال به شهرداری کرج", 13f, muted))
            }
        }

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(5), dp(7), dp(5), dp(7))
        }
        listOf("خانه" to "home", "درخواست‌ها" to "requests", "＋ ثبت" to "new", "پیگیری" to "track", "پروفایل" to "profile").forEach { (label, target) ->
            val b = text(label, 11f, if (page == target) teal else muted, page == target).apply {
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(12), dp(3), dp(12))
                isClickable = true
                setOnClickListener { page = target; showPage() }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }
}
